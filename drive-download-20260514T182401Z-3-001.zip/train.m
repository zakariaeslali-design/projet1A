%% train_final.m
clear; clc;

%% ================= LOAD DATA =================
imds = imageDatastore('dataset', ...
    'IncludeSubfolders', true, ...
    'LabelSource', 'foldernames');

numClasses = numel(categories(imds.Labels));
labels = categorical(imds.Labels);

%% ================= DETECTEUR DE VISAGE =================
detector = vision.CascadeObjectDetector();

%% ================= CNN SIMPLE OPTIMISÉ =================
inputSize = [100 100 3];

layers = [
    imageInputLayer(inputSize)

    convolution2dLayer(3,16,'Padding','same')
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2,'Stride',2)

    convolution2dLayer(3,32,'Padding','same')
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2,'Stride',2)

    convolution2dLayer(3,64,'Padding','same')
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2,'Stride',2)

    fullyConnectedLayer(128)
    reluLayer
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer
];

%% ================= PREPROCESSING DES IMAGES =================
numImages = numel(imds.Files);
X = zeros(inputSize(1), inputSize(2), 3, numImages, 'single');

for i = 1:numImages
    img = readimage(imds,i);

    % Détection visage
    bbox = step(detector,img);
    if ~isempty(bbox)
        img = imcrop(img,bbox(1,:));
    end

    % Convertir grayscale -> RGB
    if size(img,3) == 1
        img = repmat(img,[1 1 3]);
    end

    % Redimensionner
    img = imresize(img, inputSize(1:2));

    % Normaliser
    img = im2single(img);

    X(:,:,:,i) = img;
end

%% ================= OPTIONNEL : AUGMENTATION MANUELLE =================
% Exemple simple : rotation ±15°
X_aug = X;
labels_aug = labels;
for i = 1:numImages
    rotated = imrotate(X(:,:,:,i), randi([-15 15]), 'bilinear', 'crop');
    X_aug(:,:,:,end+1) = rotated;
    labels_aug(end+1) = labels(i);
end

X_train = X_aug;
Y_train = labels_aug;

%% ================= OPTIONS D'ENTRAINEMENT =================
options = trainingOptions('sgdm', ...
    'MaxEpochs',30, ...
    'MiniBatchSize',16, ...
    'InitialLearnRate',0.01, ...
    'Shuffle','every-epoch', ...
    'Verbose',false, ...
    'Plots','training-progress');

%% ================= ENTRAINEMENT =================
classifier = trainNetwork(X_train, Y_train, layers, options);

%% ================= TEST ET AFFICHAGE DE PRECISION =================
YPred = classify(classifier, X_train);
accuracy = mean(YPred == Y_train) * 100;
fprintf('✅ Taux de reconnaissance final : %.2f %%\n', accuracy);

%% ================= SAVE MODEL =================
if ~exist('models','dir')
    mkdir('models');
end
save('models/face_model_final.mat','classifier','detector');

disp("✅ Modèle sauvegardé !");
