%% predict_ORL_matched.m
clear; clc;

%% ================= CHARGER LE MODELE =================
modelPath = fullfile(pwd, 'models', 'face_model_final.mat');
if ~isfile(modelPath)
    error('Le fichier %s est introuvable', modelPath);
end
load(modelPath, 'classifier', 'detector');

%% ================= CHOIX DE L'IMAGE =================
subject = 1;      % Sujet 1 à 40
imgIndex = 1;     % Image 1 à 10

imgPath = fullfile(pwd, 'dataset', sprintf('s%d', subject), sprintf('%d.pgm', imgIndex));
if ~isfile(imgPath)
    error('Le fichier %s est introuvable', imgPath);
end

img = imread(imgPath);

%% ================= PREPROCESSING =================
bbox = step(detector,img);
if ~isempty(bbox)
    img = imcrop(img,bbox(1,:));
end

if size(img,3) == 1
    img = repmat(img,[1 1 3]);
end

inputSize = classifier.Layers(1).InputSize;
img = imresize(img, inputSize(1:2));
img = im2single(img);

%% ================= PREDICTION =================
predLabel = classify(classifier, img);

%% ================= COMPARAISON =================
trueLabel = sprintf('s%d', subject);
if strcmp(char(predLabel), trueLabel)
    matchText = '✅ Prediction MATCH le vrai label';
else
    matchText = '❌ Prediction NE MATCH PAS le vrai label';
end

%% ================= AFFICHAGE =================
figure;
imshow(img);
title({sprintf('Prédiction : %s', char(predLabel)), ...
       sprintf('Vrai label : %s', trueLabel), ...
       matchText}, 'FontSize',14);