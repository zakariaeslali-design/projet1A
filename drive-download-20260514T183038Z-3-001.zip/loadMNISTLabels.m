function labels = loadMNISTLabels(filename)

    fid = fopen(filename,'rb');
    if fid == -1
        error(['Impossible d''ouvrir le fichier : ', filename]);
    end

    fread(fid,1,'int32','ieee-be');
    fread(fid,1,'int32','ieee-be');

    labels = fread(fid, inf, 'unsigned char');
    fclose(fid);

    labels = double(labels);
end
