function images = loadMNISTImages(filename)

    fid = fopen(filename,'rb');
    if fid == -1
        error(['Impossible d''ouvrir le fichier : ', filename]);
    end

    fread(fid,1,'int32','ieee-be');
    numImages = fread(fid,1,'int32','ieee-be');
    numRows   = fread(fid,1,'int32','ieee-be');
    numCols   = fread(fid,1,'int32','ieee-be');

    images = fread(fid, inf, 'unsigned char');
    fclose(fid);

    images = reshape(images, numRows*numCols, numImages);
    images = double(images)/255;
end

