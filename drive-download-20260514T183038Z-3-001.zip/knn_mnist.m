clc; clear; close all;

X_train = loadMNISTImages('train-images-idx3-ubyte')';
y_train = loadMNISTLabels('train-labels-idx1-ubyte');

X_test = loadMNISTImages('t10k-images-idx3-ubyte')';
y_test = loadMNISTLabels('t10k-labels-idx1-ubyte');

X_train = X_train(1:10000,:);
y_train = y_train(1:10000);

X_test = X_test(1:2000,:);
y_test = y_test(1:2000);

k = 5;
Mdl = fitcknn(X_train, y_train, ...
    'NumNeighbors', k, ...
    'Distance', 'euclidean');

y_pred = predict(Mdl, X_test);

accuracy = mean(y_pred == y_test) * 100;
fprintf('Taux de reconnaissance : %.2f %%\n', accuracy);

i = 3; % indice d'image
img = reshape(X_test(i,:), 28, 28);

figure;
confusionchart(y_test, y_pred);
title('Matrice de confusion KNN - MNIST');


figure;
imshow(img', []);
title(['Vrai : ', num2str(y_test(i)), ...
       ' | Prédit : ', num2str(y_pred(i))]);
%% ================= Visualisation des erreurs =================
wrong_idx = find(y_pred ~= y_test);
numErrors = min(16, length(wrong_idx));

if numErrors > 0
    figure('Name','Exemples de mauvaises classifications KNN');
    for j = 1:numErrors
        idx = wrong_idx(j);
        img_err = reshape(X_test(idx,:), 28, 28);
        subplot(4,4,j);
        imshow(img_err', []); % transpose pour orientation correcte
        title(['R: ', num2str(y_test(idx)), ' | P: ', num2str(y_pred(idx))], 'Color','r');
    end
end


